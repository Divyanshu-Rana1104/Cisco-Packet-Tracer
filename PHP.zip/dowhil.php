<html>
<body>
<?php
$i = 0;
$num = 0;
do
{
  $i++;
$num=$num+$i;
}while( $i < 10 );
echo ("Loop stopped at i = $i<br><hr>" );
echo ("Sum=$num");
?>
</body>
</html>