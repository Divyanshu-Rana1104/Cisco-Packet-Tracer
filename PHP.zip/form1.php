<?php 
echo "Name is :";
echo $_REQUEST["name"]; 

echo "<br>Your email address is: ".$_REQUEST["email"]; 
?>