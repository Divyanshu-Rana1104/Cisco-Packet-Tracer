<?php
echo"Hello";
$arr = array( 1, 2, "Shivam", 4, 5);
print_r($arr);
?>
